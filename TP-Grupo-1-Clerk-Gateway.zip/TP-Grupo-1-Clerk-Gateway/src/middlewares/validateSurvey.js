const sendError = require('../utils/response').sendError;

// Valida que el body de la encuesta sea un objeto JSON
module.exports = (req, res, next) => {
  if (req.method !== 'POST') {
    return next();
  }

  if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
    return sendError(res, 400, 'El body debe ser un objeto JSON', req.id);
  }

  next();
};
