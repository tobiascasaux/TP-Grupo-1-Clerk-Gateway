const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middlewares/auth');
const { sendError, sendSuccess } = require('../utils/response');
const createHttpClient = require('../utils/httpClient');
const getInternalHeaders = require('../utils/internalHeaders');
const config = require('../config');
const validateSurvey = require('../middlewares/validateSurvey');

const httpClient = createHttpClient();

// POST /api/survey
// Recibe la encuesta y la envia a MS2
// Body esperado: objeto JSON de encuesta
router.post('/survey', validateSurvey, async (req, res) => {
  const internalHeaders = {
    'x-request-id': req.id,
    'x-internal-key': config.INTERNAL_API_KEY,
  };
  const ms2SurveyUrl = `${config.MICROSERVICES.MS2}/scrape`;

  console.log(`[${req.id}] POST /api/survey recibido`);
  console.log(`[${req.id}] Body recibido en gateway:`, req.body);
  console.log(`[${req.id}] Enviando encuesta a MS2: ${ms2SurveyUrl}`);
  console.log(`[${req.id}] Payload enviado a MS2:`, req.body);

  try {
    const scrapeResponse = await httpClient.post(
      ms2SurveyUrl,
      req.body,
      {
        headers: internalHeaders,
      }
    );

    console.log(`[${req.id}] Respuesta recibida desde MS2 con status ${scrapeResponse.status}`);
    console.log(`[${req.id}] Body recibido desde MS2:`, scrapeResponse.data);

    return sendSuccess(res, scrapeResponse.status, scrapeResponse.data, req.id);
  } catch (error) {
    console.error(`[${req.id}] Error en POST /survey hacia MS2:`, error.message);
    console.error(`[${req.id}] Status recibido desde MS2:`, error.response?.status || 'sin respuesta');
    console.error(`[${req.id}] Body de error recibido desde MS2:`, error.response?.data || 'sin body');
    const statusCode = error.response?.status || 500;
    return sendError(res, statusCode, 'Error al enviar encuesta a MS2', req.id);
  }
});

// GET /api/travel-plans/:id
// Obtiene un plan de viaje de MS1
router.get('/travel-plans/:id', requireAuth, async (req, res) => {
  try {
    const response = await httpClient.get(
      `${config.MICROSERVICES.MS1}/travel-plans/${req.params.id}`,
      {
        headers: getInternalHeaders(req),
      }
    );

    sendSuccess(res, response.status, response.data, req.id);
  } catch (error) {
    console.error(`[${req.id}] Error en GET /travel-plans/:id:`, error.message);
    const statusCode = error.response?.status || 500;
    sendError(res, statusCode, 'Error al obtener plan de viaje', req.id);
  }
});

module.exports = router;
